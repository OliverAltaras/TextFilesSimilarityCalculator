package ie.gmit.dip;

import java.util.*;

/**
 * The class Menu implements the {@link Menuable} interface.
 * 
 * <p>
 * This class contains three methods that are relevant for a user interface. One
 * method for displaying the options, one for acting on the choices and one that
 * combines both within a while loop and can be used by the {@link Runner} class
 * to start the application.
 * </p>
 * 
 * @author Oliver Kovacevich Altaras
 * @version 1.0
 * @see CosineCalculator
 */

public class Menu implements Menuable {
	private CosineCalculator cc = new CosineCalculator();
	private Scanner scan = new Scanner(System.in);
	private boolean keepRunning = true;
	private Thread thread = new Thread(cc);

	/**
	 * Combines the functionalities of menuLayout() and choices() in a concise way.
	 * The choices() method is put within a while loop so it is always operational,
	 * unless told otherwise by the user.
	 */
	public void go() {
		menuLayout();
		while (keepRunning) {
			choices();
		}
	}

	/**
	 * Invokes a method depending on the user's input. It uses an if-statement to
	 * either invoke the run() method, thus starting the application on a separate
	 * thread, or to quit the program.
	 */
	public void choices() {

		String menuChoice = scan.nextLine();

		// The thread is invoked if choice is "1"
		if (menuChoice.equals("1")) {
			try {
				thread.start();
				thread.join();
			} catch (InterruptedException e) {
				System.out.println("There was an issue, please restart the program.");
			}
			keepRunning = false;
		} else if (menuChoice.equals("2")) {
			keepRunning = false;
			System.out.println("Bye-bye! =(");
		} else {
			System.out.println("Invalid option! You must choose either 1 or 2>");
			choices();
		}

	}

	/**
	 * Displays the text interface of the main menu. As this is a command line
	 * application, it uses strings to present the information for the user.
	 */
	public void menuLayout() {
		System.out.println("**************************************");
		System.out.println(" Welcome to File Comparator G00387943 ");
		System.out.println("**************************************");
		System.out.println("");
		System.out.println("1 - Compare two files>");
		System.out.println("2 - Quit>");
		System.out.println("");
		System.out.println("Type option [1 or 2]>");
	}
}

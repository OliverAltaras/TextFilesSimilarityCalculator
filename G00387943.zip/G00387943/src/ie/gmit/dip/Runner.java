package ie.gmit.dip;

/**
 * The class Runner contains the main method for the File Comparator G00387943
 * application.
 * 
 * <p>
 * Its sole purpose is to launch the program by invoking all of the program's
 * classes and interfaces.
 * </p>
 * 
 * @author Oliver Kovacevich Altaras
 * @version 1.0
 * @see Menu
 */
public class Runner {

	/**
	 * Initiates the application by invoking the go() method from the {@link Menu}
	 * class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		new Menu().go();

	}
}

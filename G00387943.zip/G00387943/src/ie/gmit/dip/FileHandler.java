package ie.gmit.dip;

import java.io.*;
import java.util.*;

/**
 * The class FileHandler is responsible for parsing text files into Maps.
 * 
 * <p>
 * It contains a single method which can be used both to parse query and subject
 * files, and is then used by the CosineCalculator class.
 * </p>
 * 
 * @author Oliver Kovacevich Altaras
 * @version 1.0
 * @see CosineCalculator
 */

public class FileHandler {

	private BufferedReader br;
	private String line;

	/**
	 * Uses a Map to parse a text file and convert the strings to hashcode.
	 * 
	 * The Map is composed of two Integer types, one for the key and one for the
	 * value of the map. The key is the unique word(converted to hashcode), whereas
	 * the value is its frequency.
	 * 
	 * @param file - String with the path of the text files to be parsed
	 * @return a Map where the hashcode and frequency are stored
	 * @throws IOException
	 */
	public Map<Integer, Integer> getFile(String file) throws IOException {

		Map<Integer, Integer> comparedFile = new HashMap<>();

		br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

		while ((line = br.readLine()) != null) {
			// this splits the String whenever a space or any of the special characters
			// appears. This way it only compares words
			String[] words = line.split("[ \\.\\,\\?\\!\\)\\(]+");
			for (String word : words) {
				// move everything to lower case
				String lcWord = word.toLowerCase();
				int hash = lcWord.hashCode();
				int frequency = 1;
				if (comparedFile.containsKey(hash)) {
					frequency += comparedFile.get(hash);
				}
				comparedFile.put(hash, frequency);
			}
		}
		br.close();
		return comparedFile;
	}
}

package ie.gmit.dip;

/**
 * The interface Menuable is an abstraction of a menu.
 * 
 * <p>
 * It contains the abstraction of the methods needed to create a simple Menu
 * class. It should be implemented when a command line user interface is
 * required.
 * </P>
 * 
 * @author Oliver Kovacevich Altaras
 * @version 1.0
 * @See Menu
 */
public interface Menuable {

	/**
	 * Creates a method that should invoke different behaviours depending on the
	 * user input.
	 */
	public void choices();

	/**
	 * Displays the options available to the user.
	 */
	public void menuLayout();

}

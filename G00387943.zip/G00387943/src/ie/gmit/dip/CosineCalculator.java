package ie.gmit.dip;

//The link made available on Moodle, https://blog.nishtahir.com/fuzzy-string-matching-using-cosine-similarity/#fn2,
//was used to assist in the implementation of the cosine calculator

import java.io.IOException;
import java.util.*;

/**
 * The class CosineCalculator is responsible for calculating the cosine distance
 * between two text files.
 * 
 * <p>
 * It implements the Runnable interface, therefore creating a run() method and
 * allowing the calculator to run on a separate thread from other features of
 * the application.
 * </p>
 * 
 * <p>
 * The class also contains a method allowing users to input text files and a
 * method that calculates the cosine distance between those text files.
 * </p>
 * 
 * @author Oliver Kovacevich Altaras
 * @version 1.0
 * @see FileHandler
 */

public class CosineCalculator implements Runnable {
	private FileHandler fl = new FileHandler();
	private Scanner scan = new Scanner(System.in);
	private double dotProduct;
	private double queryMagnitude;
	private double subjectMagnitude;
	private String queryFile, subjectFile;

	/**
	 * Allows for user input of the query and the subject files. It does so by using
	 * a Scanner. The inputs are then saved as variables and passed as arguments to
	 * the getFile(file) method of the FileHandler class.
	 */
	public void inputFiles() {
		System.out.println("Please enter the query file>");
		queryFile = scan.nextLine();

		System.out.println("Please enter the subject file>");
		subjectFile = scan.nextLine();
	}

	/**
	 * Calculates the cosine similarity between a query and a subject file.
	 * <p>
	 * It does so by storing the files as HashMap variables. It then gets the dot
	 * product by creating a Set with the unique words(keys) of those variables.
	 * Then, the magnitudes of the query and subject files are calculated. Once this
	 * is done, the formula for establishing the cosine distance is used. Finally, a
	 * last formula is used to turn that result into a percentage from 0% to 100%,
	 * making sure that only up to two decimal places are used.
	 * </p>
	 * 
	 * @return a double, which is the percentage of similarity
	 * @throws IOException
	 */
	public double similarityCalculator() throws IOException {

		// Gets text files, specified by the user input (previous method)
		HashMap<Integer, Integer> query = new HashMap<>(fl.getFile(queryFile));
		HashMap<Integer, Integer> subject = new HashMap<>(fl.getFile(subjectFile));

		// Gets the intersection of both maps, creating a set with their keys(unique
		// words)
		Set<Integer> intersection = new HashSet<>(query.keySet());
		intersection.retainAll(subject.keySet());

		// Gets the dot product
		for (int item : intersection) {
			dotProduct += query.get(item) * subject.get(item);
		}

		// Gets the magnitude of the query file
		for (int queries : query.keySet()) {
			queryMagnitude += Math.pow(query.get(queries), 2);
		}

		// Gets the magnitude of the subject file
		for (int subjects : subject.keySet()) {
			subjectMagnitude += Math.pow(subject.get(subjects), 2);
		}

		// Creates a variable with a cosine value between 0.0 and 1.0
		double cosineValue = dotProduct / Math.sqrt(queryMagnitude * subjectMagnitude);

		// Returns the percentage value of the cosine distance
		// The code below also ensures that only up to 2 decimal places are used
		return Math.round(cosineValue * 10000.0) / 100.0;
	}

	/**
	 * Creates a thread by executing the code inside of it. This method is inherited
	 * from the Runnable interface.
	 * 
	 * <p>
	 * It is then invoked by the user on the {@link Menu} class.
	 * </p>
	 */
	public void run() {
		try {
			inputFiles();
			System.out.println("\nThe cosine similarity is of " + similarityCalculator() + "%");
			System.out.println("\nType 1 to compare again. Type 2 to quit>");
			new Menu().choices();
		} catch (IOException e) {
			System.out.println("The file was not found. Type 1 to try again | Type 2 to quit>");
			new Menu().choices();
		}
	}
}
